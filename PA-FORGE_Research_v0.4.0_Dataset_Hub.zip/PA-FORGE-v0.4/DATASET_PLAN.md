# External data ingestion plan (no external archives bundled)

- **OADAT** — experimental forearm signals; inspect the licensed source release and verify original channel geometry, axes, time-zero, and wavelength before writing a dataset-specific loader. Dataset is reported noncommercial. https://github.com/berkanlafci/oadat
- **PAISKINTONE** — multiple sites including radial/carotid; verify raw array layouts and independent participant identifiers. https://zenodo.org/records/20068219
- **OpenQPAIData** — measured test objects with reference optical properties, 3 devices; inspect its IPASC raw files first and use as cross-device/device-physics reference. Dataset reported CC BY 4.0. https://github.com/BohndiekLab/OpenQPAIData
- **Synthetic Vascularized Digital Skin Phantoms** — synthetic optical maps and sinograms only, not independent real human raw data. https://zenodo.org/records/21785486
- **Brown et al., Cambridge vascular mesoscopy** — in-silico vascular-network masks, reconstructed RSOM images, segmentation and phantoms (CC BY-NC 4.0). Useful for **vessel morphology** and topology, not confirmed detector time series. https://doi.org/10.17863/CAM.78208
- **ShanghaiTech vessel phantom** — 7.7GB archive; channel/time-series status and license have not been inspected. https://zenodo.org/records/10719987
- **Breast PACT/URCT** — imaging data with human tumor reconstructions; no raw sensor waveforms confirmed. https://doi.org/10.5061/dryad.vmcvdnd55

The catalog in `data_catalog/sources.yaml` separates verified-public-dataset descriptions from locally inspected array formats. **This package has NOT fetched or validated these archives.** The original authors' assets and clinical images are not redistributed.

## Conservative import workflow

```bash
paforge inspect-data /path/to/downloaded.mat
paforge import-data /path/to/downloaded.mat --key signal_array_key \
  --output external_data/imported.h5 --detector-axis 0 \
  --sampling-rate-hz YOUR_KNOWN_SAMPLE_RATE --wavelength-nm YOUR_KNOWN_WAVELENGTH
```

The importer refuses to guess axes or sample rate. Detector positions should be supplied with `--positions xyz_metres.npy` if they are known; its expected shape is `[detector, 3]` in meters. Imported records **without** validated geometry cannot be treated as reproducibly reconstructible raw experimental data.

For subject-disjoint splits, create a CSV with `sample_id,subject_id` and run:

```bash
paforge make-splits data_metadata.csv --output splits --group-column subject_id
```

A future adapter should additionally record file checksums, device calibration, optical/acoustic coupling, illumination pattern, participant consent/use scope and reconstruction time origin.
