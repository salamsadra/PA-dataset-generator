# PA-FORGE v0.3 — Experimental calibration and held-out domain-validation guide

## Scope and status

**Current status: real-data-ready protocol, NOT a completed experimental result.** The runtime used to build this release did not have network access to retrieve experimental archives, and there were no original experimental acquisitions supplied. Tests exercise artificial/mock measurements only. Do **not** cite their results as photoacoustic experimental validation.

v0.3 adds: (1) explicit extraction from high-dimensional HDF5; (2) independent-group provenance-gated manifests; (3) train-only spectral-domain statistical calibration and optional genuine *quiet-window* noise extraction; (4) frozen held-out comparison of simulated and experimental *signal distributions*; (5) qualitative reconstruction from real raw traces **when actual detector coordinates are supplied**; (6) deterministic application of a trained domain profile to new simulated signals; (7) explicit checks for train/test leakage and synthetic mislabeling.

## First empirical dataset: OpenQPAIData (recommended)

- Source: https://zenodo.org/records/14044853
- Code and schema: https://github.com/BohndiekLab/OpenQPAIData
- Original experimental tissue-mimicking phantoms, reference segmentations, optical property maps, raw detector time series in IPASC HDF5.
- Imaging devices: InVision (typically 256 × 2030 × 1 × 1), TROPUS (typically 512 × 2094 × 1 × 1), SVOT has 3D reconstructions. Dimensions must be checked in each actual file; no assumed key or axes.
- Archive published on Zenodo: `invision.zip` (~238 MB), `tropus.zip` (~287 MB), `DIS.zip` (~132 MB), `svot.zip` (~19.8 GB). **Download InVision first.** Dataset CC-BY 4.0 per its repository; attribution required.
- Real experimental test = independently held-out **phantom IDs**, not separate wavelengths or acquisitions of the same physical phantom. A stricter generalization test holds out an entire instrument, but such tests require carefully documented harmonization.

Optional later sources:

- OADAT https://github.com/berkanlafci/oadat — raw experimental human forearm measurements (1064 nm); CC BY-NC 4.0; 14 people. Split by **person**, not slice/arm; can test human-organ generalization. Never assume OADAT scanner specifications match OpenQPAIData.
- PAISKINTONE https://zenodo.org/records/20068219 — multi-wavelength human data at radial artery, bicep, calf, carotid; major multi-GB archives. Split by **participant**, not scan or site. Licenses must be confirmed before redistribution.

## Run with genuine OpenQPAIData acquisitions

1. Download and unzip `invision.zip` from Zenodo onto your machine. If your computer has network access, you can use `paforge download-openqpai --archive invision --unpack --output data/openqpai` (MD5-verified). For measured optical-property data, use `--archive dis` separately. Preserve original metadata. No experimental file downloads are bundled with PA-FORGE. Review `README_data.md` from the source repo.
2. Inspect a specific raw HDF5 file and note dataset key and every array dimension. Obtain sampling frequency from the source **metadata** (not guessed from array shape). Determine the original detector coordinates from IPASC device metadata or PACFISH. Example inspection:

```bash
paforge inspect-data /path/to/original_invision.hdf5
```

3. Extract a **single** acquisition. Example shown assumes the inspected binary time series has dimensions `[detectors,time,wavelength,frame]` **and** that the named dataset key is correct. Adjust to the actual file; substitute the actual metadata value of the sampling frequency and wavelength. The illustrative `1e7` and `800` below are placeholders and **must not be used as inferred acquisition parameters**.

```bash
paforge extract-acquisition /path/to/source.hdf5 \
  --key binary_time_series_data \
  --detector-axis 0 --time-axis 1 \
  --fixed-axis 2=0 --fixed-axis 3=0 \
  --sampling-rate-hz <VERIFIED_HZ> --wavelength-nm <VERIFIED_NM> \
  --source-id OpenQPAIData-14044853 --group-id <PHANTOM_ID> \
  --attest-experimental --output data/real/phantom_01_a.h5
```

For IPASC, prefer `pacfish.load_data(...)` when available to inspect `binary_time_series_data` and the associated acquisition/device metadata. If detector-coordinate metadata are available in the original HDF5, export to a NumPy array of shape `[detectors,3]` in **metres**. Never silently substitute simulated circular array positions.

4. Generate synthetic samples with **exactly compatible** detector count, digitization time, and sampling rate. The v0.3 domain comparator *refuses* nonmatching sample frequency/count/detector count. A device-aware acoustic forward model, conversion/resampling or measured acquisition geometry will be required to reach this stage for most instruments; **v0.2 default simulations are not automatically compatible with InVision/TROPUS**. Equating their metadata without matching the actual acquisition is scientifically invalid.
5. Create a CSV manifest as described next. Assign phantom groups to train/validation/test **before fitting anything**. For a small experiment use >= 3 distinct phantoms, preferably far more. Keep test phantoms untouched until the profile is frozen. Every acquisition from one phantom must have the same split.

`manifest.csv` headers:

```csv
path,group_id,domain,split,signal_key,detector_axis,sample_rate_hz,source_id,experimental_attestation,quiet_start,quiet_stop
```

Use `domain=experimental` for actual, author-attested experimental records; `domain=simulation` for independent simulator samples. Use `experimental_attestation=yes` only after verifying data provenance. `split` must be exactly `train`, `validation` or `test`. `signal_key=raw_data`, `detector_axis=0` apply to the extracted native sample. `quiet_start`/`quiet_stop` may be left empty unless you have **verified** a PA-signal-free window.

6. Validate the statistical waveform gap:

```bash
paforge validate-domains manifest.csv --output validation/real_vs_synthetic
```

If and **only if** you have verified genuinely signal-free time windows in *every experimental training trace*, optionally extract empirical noise:

```bash
paforge validate-domains manifest.csv --output validation/with_noise --extract-quiet-noise
```

Outputs include `calibration_profile.json` (train-only), `report.json` (source hashes, train/test groups, before/after signal-distribution metrics) and optionally `empirical_quiet_noise.npz` (compatible with PA-FORGE empirical-noise engine).

7. To apply the **frozen statistical profile** to a compatible synthetic raw signal record:

```bash
paforge apply-domain-profile data/synthetic/sample.h5 \
  validation/real_vs_synthetic/calibration_profile.json \
  --output data/synthetic_adapted/sample.h5
```

This **does not** inject noise when the signal's noise mode was OFF. The operation deterministically shapes its recorded spectrum. Never call it a calibrated detector impulse response.

8. To reconstruct an original acquisition qualitatively, attach the **measured** sensor coordinates in an `.npy` `[detector,3]` array (metres) to the imported HDF5 or provide `--positions`:

```bash
paforge reconstruct-acquisition data/real/phantom_01_a.h5 \
  --positions metadata/real_detector_positions_m.npy \
  --method ubp --fov-m 0.04 --grid-size 128 \
  --sound-speed-m-s 1500 --output validation/phantom_01_reconstruction
```

This uses a homogeneous 2D backprojection approximation. It is a visual baseline, **not** a registered gold-standard reconstruction, nor the previously matched iterative FDTD inverse (which currently cannot directly handle arbitrary real acquisition clocks, 3D aperture geometries and device responses). Detector z-spread >2 mm is rejected because planar projection would be dubious.

## What is and is not validated

- `spectral_js_nats`: Jensen–Shannon divergence between average normalized signal PSDs; lower means closer **in this statistic only**. It is not SSIM, PSNR, sample-wise reconstruction error or experimental realism.
- `log10_rms_wasserstein`: Wasserstein distance between logarithmic per-record signal RMS distributions; lower means closer in digital amplitude statistics. For data without calibrated pressure units, **absolute amplitude is not physically meaningful**.
- Spectrum matching learned on **train** is tested on withheld phantoms in **test**. Test data are never used to fit nuisance filters or gains. No automatic resampling because it may introduce undocumented waveform changes.
- The signal-domain metric cannot alone prove the model improved reconstruction generalization. A publishable study needs independent real reference labels, scanner-aware forward models, baselines, tests across phantoms/subjects/devices, and reference-image fidelity/task accuracy on held-out experimental samples.
- Model-source mismatch (e.g., simulated vascular anatomy vs nonvascular phantom) may dominate domain distance; a better score can reflect learned artifacts. Pair anatomy/device/material strata deliberately.
- Reusing wavelength scans from the same phantom across train/test is leakage.

## Recommended next acceptance tests

A. InVision raw file loaded; metadata and detector geometry cross-checked against IPASC/PACFISH; no artificial assumptions.
B. Independent phantom-group train/test cohorts and sha256 provenance manifest exported.
C. Real quiet-window noise is independently checked and calibrated in detector digital units, if scientifically possible.
D. Compare conventional simulation versus train-calibrated simulation on **held-out** experimental waveforms and matched phantoms.
E. Reconstruct the same held-out real acquisitions using at least one published method and the improved forward model. Compare with known segmentation/reference reconstructions after a **predefined** coordinate registration.
F. Report effect sizes, variance/uncertainty, and failure cases, not just one favorable image.

## Runtime caveat

The current artifact contains code and mock-only integration tests but **zero acquired experimental samples**. It therefore cannot show numerical real-data gains. The project explicitly withholds any clinical, experimental-generalization or physical-calibration claim until A–F are actually executed.
