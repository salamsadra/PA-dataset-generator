# PA-FORGE Research Edition — v0.4.0

**Executable photoacoustic research software:** five anatomical phantom profiles (including *vascular networks with independently labelled arteries, veins and capillaries*), raw ultrasound sensor traces, separately exportable reconstructed images and tissue maps, optional independent noise engines, a local Gradio control panel, a conditional vessel VAE and a reproducible synthetic-only benchmark.

> **Scientific boundary:** This release is a functional **2D synthetic numerical research prototype**, not an experimentally validated patient-image/data generator. No human photoacoustic dataset or real-human trained model has been downloaded or bundled. Current optics are an attenuation proxy or idealized uniform illumination; current acoustics are simple second-order heterogeneous FDTD with sponge boundaries. Refer to `RESEARCH_PROTOCOL.md` before publishing any results.

## Quick install

Python 3.10+; **3.11/3.12 recommended**. From the unzipped `PA-FORGE-v0.4/` folder:

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e '.[dev,ui,train]'
python -m pytest -q
```

The first install needs internet to retrieve any unavailable Python dependencies. Torch training is optional: for just the simulator and tests, `pip install -e '.[dev]'`; UI `pip install -e '.[ui]'`.


## NEW in v0.4: integrated dataset downloading

A unified dataset hub is included for **nine academic dataset sources** (eight programmatic download methods and one guided publisher source). Live dataset catalogs are discovered from publisher APIs where available. Every source is handled individually with per-file integrity, size budgets, and status logging.

```bash
paforge datasets list
paforge datasets inspect openqpai
paforge datasets download --all --profile starter --accept-licenses --output data/external
```

This command downloads selected **starter assets**, not hundreds of gigabytes automatically. For complete Zenodo/Dryad/Cambridge records, use `--profile full` and explicitly increase disk limits. **OADAT requires a guided publisher download** until a safe subset API can be verified. See [DATASET_DOWNLOAD_GUIDE.md](DATASET_DOWNLOAD_GUIDE.md) for per-source capability, file-type differences, and verification status. No data is downloaded by merely installing or launching PA-FORGE.

### Experimental-data status

The acquisition hub is runnable and has automated tests, but publisher archives have **not** been downloaded in this environment. Downloading does NOT mean dataset-specific ingestion, measured-device calibration, real training or simulation-to-real validation. Those are separate steps to run with actual accessible raw data.

## Run it immediately

### New: dedicated blood-vessel dataset (رگ)

```bash
paforge demo --anatomy vascular --vascular-pattern branching \
  --grid-size 96 --time-steps 420 --transducers 48 \
  --reconstruction-method iterative --no-filter --no-noise \
  --samples 1 --output output_vascular
```

Outputs include `vessel_types.png`, `ground_truth.h5` (artery=1, vein=2, capillary=3, other vessel=4), `raw_signals.h5`, `reconstruction.h5`, `reconstruction.png`, `manifest.json` and `overview.png`.

### All original anatomies remain

```bash
paforge demo --anatomy forearm --no-noise --output out_forearm
paforge demo --anatomy skin --no-noise --output out_skin
paforge demo --anatomy breast --no-noise --output out_breast
paforge demo --anatomy carotid --no-noise --output out_carotid
```

### GUI

```bash
paforge ui
```

Open **http://127.0.0.1:7860**. Control anatomy, vascular profile, branch levels, reconstruction, laser wavelength, detector count, geometry, tissue scattering and noise. The interface is **local**; it does not upload data to a server.

### Repeatable YAML simulation

```bash
paforge generate examples/vascular_config.yaml --output output_yaml
```

## Noise OFF means all noise engines OFF

Noise is disabled by default; the entire stochastic-noise pipeline is bypassed when `noise.enabled=false`. Its engine list may contain all five names and **still generates identical `raw_data` and `clean_detector_signals`**, with no added noise. Laser pulse jitter, dropouts and detector filtering are separate physical/acquisition settings and are not disabled by this switch.

Selectable, composable engines: `gaussian`, `colored`, `impulsive`, `drift`, `empirical`. The empirical engine **requires a local genuine noise recording** (`.npy`, `.npz` key `noise` or `.h5` path `/noise`) and will fail if absent; it never synthesizes a fake "empirical" library.

```bash
paforge demo --anatomy vascular --noise --engine gaussian --engine colored --output out_noisy
```

SNR is reported after generation; it is **not** a guaranteed user-specified target.

## Reconstruction methods

- `ubp` (default): derivative-weighted, UBP-inspired qualitative backprojection; approximate formula, no exact scanner calibration.
- `das`: unweighted plain time-of-flight delay-and-sum, weak baseline.
- `adjoint`: exact transpose of the locally implemented **discrete 2D FDTD forward operator** (not a direct inverse).
- `iterative`: nonnegative regularized FISTA using the exact discrete FDTD forward and adjoint. **Requires** `--no-filter`; assumes known device geometry and sound-speed map. A matching simulator and inverse share the forward model, which is an *inverse crime* as a scientific benchmark and **not evidence of experimental generalization**.

Run the **synthetic-only** reconstruction experiment:

```bash
paforge benchmark --anatomy vascular --seeds 3 --iterations 12 \
  --grid 64 --transducers 24 --output research_results
```

Creates `metrics.csv`, `results.json`, `comparison.png`, `metric_summary.png`. No external dataset is needed. The included `examples/research_benchmark/` contains an actually executed example. Its image error values are shape diagnostics and do not measure calibrated absorption.

## Generative anatomy options

1. `procedural` (**default**). Explicit branching, paired, and plexus networks, synthetic arterial/venous class masks. This is the guaranteed working path.
2. `cvae` (**optional**). Earlier generic vessel-mask cVAE; requires trusted weights, does not label arterial versus venous identity.
3. `vascular_cvae` (**optional**). Trainable four-class vascular CVAE (`background`, `artery`, `vein`, `capillary`) using labelled 64×64 segmentation maps. It **rejects** undertrained models that collapse to background instead of inventing vessels. Works only for `anatomy=vascular`.

Train the multiclass model on **procedural demonstration data** (smoke-test, not published scientific evidence):

```bash
paforge train-vascular-demo --weights models/synthetic_vascular.pt --samples 64 --epochs 8
```

Train on manually curated, **legally usable and independently annotated** multi-class real vascular data (if you have them):

```bash
paforge train-vascular your_training_types.npz models/vascular.pt --epochs 50
```

`your_training_types.npz` must contain `types` of shape `[N,64,64]` with integer codes 0–3. Use subject-disjoint splits (see `paforge make-splits`). **The present project does not include experimental arterial/venous labels or real-trained weights.** A short synthetic training run can be underfit and fail to sample vessel networks; the simulator's procedural mode remains available.

For loaded weights set `anatomy_engine: vascular_cvae`, `generator_weights: /absolute/path/to/model.pt` in YAML. Load weights **only from trusted sources**.

## Separate files and metadata

Each sample has these separate outputs:

```
output_vascular/vascular_00000/
  raw_signals.h5        [channels,time], dt, 3D transducer positions,
                        clean signals and optional named noise components
  reconstruction.h5    image and method metadata
  reconstruction.png   display preview
  ground_truth.h5      absorption, scattering, sound-speed, synthetic
                        initial pressure, vessel masks and type masks
  vessel_types.png     artery/vein/capillary preview (vascular mode)
  manifest.json        config, noise mode, randomness, assumptions
  overview.png         generation preview (demo)
```

Native HDF5 format is **NOT certified IPASC**. The international IPASC standard concerns raw detector time-series and acquisition metadata; certification through PACFISH is a future step.

## External-data workflow

```bash
paforge inspect-data /path/to/experimental_data.h5
paforge import-data /path/to/experimental_data.h5 --key raw_signals \
  --output imported_raw.h5 --detector-axis 0 \
  --sampling-rate-hz 20000000 --wavelength-nm 800
paforge make-splits metadata.csv --output splits --group-column subject_id
```

Example sampling rates/wavelengths here are **placeholders**. Use experimentally documented real metadata; the importer deliberately will not infer axes or rates. See `DATASET_PLAN.md` and `data_catalog/sources.yaml` for public datasets and licensing checks.

## Tests and scientific integrity

`python -m pytest -q` runs unit/integration validation, including homogeneous and heterogeneous discrete adjoint dot tests, 5 anatomy modes, 3 vascular patterns, noise OFF invariance, acoustic arrival, file outputs, dataset imports, splits, synthetic benchmarks and GUI construction. CI workflow included at `.github/workflows/tests.yml`.

**Not passed / not claimed:** clinical accuracy; experimentally calibrated light transport; radiative transfer; k-Wave cross-validation; IPASC certification; real-human generative training; cross-device experimental evaluation; verified generalization to people.

## External technical references

- k-Wave Python numerical acoustic modeling: https://k-wave-python.readthedocs.io/en/latest/get_started/new_api.html
- IPASC consensus data format (Gröhl et al., *Photoacoustics*, 2022): https://pmc.ncbi.nlm.nih.gov/articles/PMC8917284/
- Cambridge vascular mesoscopy dataset (Brown et al.): https://doi.org/10.17863/CAM.78208
- ShanghaiTech Vessel Data: https://doi.org/10.5281/zenodo.10719987
- OpenQPAIData: https://github.com/BohndiekLab/OpenQPAIData

This project includes no third-party dataset files. Resolve the repository's distribution license before public release.

---

## v0.3 Experimental readiness and honest validation boundary

See **[EXPERIMENTAL_VALIDATION_GUIDE.md](EXPERIMENTAL_VALIDATION_GUIDE.md)** and **[VALIDATION_REPORT_v0.3.md](VALIDATION_REPORT_v0.3.md)**.

The new commands are `paforge download-openqpai`, `paforge extract-acquisition`, `paforge validate-domains`, `paforge apply-domain-profile`, and `paforge reconstruct-acquisition`. They create a reproducible, provenance-gated pipeline for comparing actual instrument waveforms against simulated recordings with unmodified held-out phantom/subject groups. They **do not** certify physical detector calibration or prove reconstruction gains without external experimental files and reference images. Tests use mock waveforms only.

**Noise OFF** is preserved as the default. A user can opt into one or more Gaussian, colored, impulsive, drift or genuine empirical-noise engines; spectral domain adaptation is a separate, deterministic operation.
