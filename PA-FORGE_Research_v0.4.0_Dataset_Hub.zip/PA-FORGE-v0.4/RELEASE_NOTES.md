# Release notes — PA-FORGE Research Edition 0.2.0

- Original forearm, skin, breast, and carotid modes preserved.
- New vascular mode with labels for arteries, veins, and capillaries and branching/paired/plexus patterns.
- Separate vascular segmentation preview and HDF5 class maps.
- Correct discrete adjoint for internal second-order heterogeneous FDTD, tested via numerical dot products.
- New UBP-like derivative backprojection baseline and nonnegative FISTA iterative inversion.
- Repeatable synthetic numerical benchmark and results/figures (matched model explicitly described as an inverse crime).
- Trainable multiclass vascular CVAE (real human models and weights NOT provided).
- Group-disjoint participant split utility, dataset registry extensions, test workflow and research methodology.
- Noise-off guarantee unchanged and still tested; five composable noise engines.
- Uniform idealized optical illumination for vascular numerical studies (nonphysical in real tissue; switch to attenuation proxy for scattering effects).

## Known limitations

Physics is approximate (2D FDTD with sponge, heuristic or uniform optics). No real experimental raw-signal datasets downloaded, verified, harmonized or trained; no independent k-Wave validation; no PACFISH IPASC conformance verification. Do not assert medical realism, biological physiological accuracy, guaranteed SNR, or real-data performance.
