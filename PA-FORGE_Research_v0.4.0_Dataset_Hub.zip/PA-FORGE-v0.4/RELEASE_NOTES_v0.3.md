# Version 0.3.0 (experimental-readiness research release)

Includes an optional MD5-verified OpenQPAIData InVision/TROPUS/DIS archive downloader for machines with internet access.

Upgrades v0.2 vascular edition without removing previous anatomy, vascular, signal-generation, GUI, or optional noise features. Adds explicit 2D extraction from complex HDF5 sources; provenance attestations and synthetic mislabel rejection; group-held-out train-only spectral comparison; source file hashes; optional quiet-window noise extraction; statistical synthetic-domain profile application; original measured-signal qualitative reconstructions requiring measured detector geometry; and tests. See `EXPERIMENTAL_VALIDATION_GUIDE.md` and `VALIDATION_REPORT_v0.3.md` for commands and hard scientific limitations.

**Not performed:** real archive download, numerical physical calibration to an actual scanner, independent real reconstruction benchmark. The v0.2 iterative FDTD method remains a matched numerical synthetic inverse and is not silently applied to real IPASC acquisitions.
