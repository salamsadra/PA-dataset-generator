# v0.4 — Dataset Download Hub

- Added `paforge datasets list`, `inspect`, and `download` CLI.
- Publisher API adapters for OpenQPAIData, PAISKINTONE, synthetic skin, PAM3, PhotIQA, ShanghaiTech and Breast Dryad.
- Cambridge vascular repository direct published-bitstream assets (publisher-reported sizes are approximate).
- OADAT official ETH shared-drive guide entry; automatic subset listing is not verified and giant bulk downloading is intentionally disabled.
- Controlled starter/full plans, max file and total byte budgets, resumable `.part` downloads, published checksums where available, protected archive extraction and per-source JSON provenance/status reports.
- No change to the experimental calibration claims: there is still **no executed real acquisition validation** or real data bundled with the code.
- See `DATASET_DOWNLOAD_GUIDE.md` for exact commands and limitations.
