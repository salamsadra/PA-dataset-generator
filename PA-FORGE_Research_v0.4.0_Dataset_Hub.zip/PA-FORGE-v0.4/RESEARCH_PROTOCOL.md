# PA-FORGE — Experimental methodology and validation protocol

**Current result: numerical prototyping only.** The attached benchmark is synthetic, and the reported matched iterative reconstruction is an *inverse crime*. It must never be presented as experimental evidence or an improvement on public datasets.

## Research hypothesis

A real-data-calibrated, physics-conditioned anatomical generator can eventually produce raw photoacoustic detector measurements that improve reconstruction and vessel segmentation under domain shift compared with conventional procedural numerical augmentation.

This is a **hypothesis to test**, not a result of the included version.

## Proposed scientific experiments

1. **Numerical correctness (implemented):** pressure zero-invariance, point-source travel time, stability checks, deterministic seed handling, bilinear sampling/adjoint dot products (homogeneous and heterogeneous), exact absence of injected stochastic noise when disabled, 5 anatomy output modes, HDF5 schema checks.
2. **Reconstruction baselines (implemented):** vanilla DAS; derivative-weighted UBP-like heuristic; exact discrete FDTD adjoint; regularized nonnegative FISTA. The FISTA inversion assumes known acoustic sound speed and sensor positions and `detector_filter=false`.
3. **Numerical perturbations (partially implemented):** independent electronic-noise engines, channel loss and pulse jitter. Add limited-angle studies and forward-model mismatch comparisons before claims about robustness.
4. **Physics calibration (NOT implemented):** cross-check against k-Wave (see official k-Wave-python documentation), calibrate acoustic attenuation/directivity and laser fluence with actual phantom experiments, and verify detector impulse responses.
5. **Real anatomy generation (NOT done):** source clinically licensed segmented anatomy from independent subjects; use participant-level train/validation/test splits using `paforge make-splits`. The simple VAE is demonstrative and **not trained on human vessels** in this package.
6. **Experimental raw-waveform calibration (NOT done):** import real recordings using the verified channel/time axes, sample timing, detector coordinates, time-zero and wavelength. Reuse can be constrained by third-party dataset licenses. Inspect with `paforge inspect-data`; do not infer unknown axes.
7. **Real-data downstream generalization (NOT done):** compare training on real-only, conventional synthesis, generic image augmentation, and proposed synthesis on completely held-out participants/devices. Report repeated-seed confidence intervals and independent-device validation.

## Dataset leakage and inverse crime safeguards

Never put acquisitions of the same donor, phantom or continuous sweep into independent train and test groups. Filename-level random splitting is not sufficient. Avoid patient overlap between anatomy prior training and reconstruction evaluation. The synthetic benchmark's iterative solver uses **exactly the same** numerical wave model for inversion; this must be clearly identified as an inverse crime.

## Evaluation metrics

Reconstruction: normalized Pearson correlation, SSIM/PSNR **only** when spatial registration and valid reference maps are present. `oracle_scale_nrmse` optimally rescales a reconstruction using the known synthetic truth, making it a *diagnostic research metric*, not a deployable real-data result. Distinguish structural image metrics from quantitative absorption accuracy.

Vascular segmentation: Dice/IoU, sensitivity, false-positive rate, centerline topology, and vessel diameter error, reported by artery, vein and capillary **only when those classes are truly annotated**. Synthetic class labels are not verified clinical arterial/venous ground truth.

Noise: report realized added-noise SNR with explicitly stated signal/noise definitions, and keep acquisition imperfections independent from added stochastic noise.

## Biological limitations

The model is a **2D slice** in a simplified material model. It is not a full 3D human vascular tree. Vessel thickness and branch angles are procedural demonstration values, not subject-conditioned physiological distributions. Artery/vein absorption values and the wavelength factor are not experimentally calibrated oxygenation spectra. `uniform_idealized` is an optical ablation with constant fluence; optical scattering does not affect outputs in that mode. `attenuation_proxy` is a heuristic and not radiative transfer/Monte Carlo.

## Publication gates

- Real raw-signal dataset adapters independently verified on downloaded source files, including format and licensing.
- Numerically validated optical and acoustic forward models, ideally against established solvers.
- A learned generative model trained on licensed, properly split real anatomy/experimental information.
- Quantitative sim-to-real results on disjoint independent human/phantom acquisitions; meaningful ablations and uncertainty intervals.
- Dataset and code release with appropriate attribution, licenses and machine-readable provenance.

Until then, the project should be described as **an executable research codebase with synthetic numerical benchmarks**.
