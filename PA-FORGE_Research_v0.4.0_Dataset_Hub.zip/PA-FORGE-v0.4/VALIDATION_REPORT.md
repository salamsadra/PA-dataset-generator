# PA-FORGE v0.1.0 verification report

## What was checked locally

- Static config validation and four anatomy presets.
- Zero stochastic noise output and bit-identical clean/raw traces when disabled.
- Noise ON reproducibility; anatomy invariant to noise toggles.
- Gaussian, colored, impulsive, baseline drift, empirical engines individually.
- Five active engines simultaneously using a valid local noise file.
- Missing experimental noise file raises an explicit error, never a fallback.
- Zero initial pressure produces exactly zero propagated pressure.
- Centered Gaussian acoustic pulse arrives near the predicted homogeneous travel time.
- Real finite arrays and valid dimensions for all four anatomical profiles.
- Distinct HDF5 raw, reconstructed image, and ground-truth exports.
- Manual source-file inspection and explicit-axis raw HDF5 import.
- Gradio control panel constructs successfully and generates an archive.
- PyTorch conditional vessel VAE trains for a single smoke-test epoch on
  **procedural masks** and can produce a nonempty learned-prior vessel mask.

**Result:** 27 automated pytest checks passed. Further manual integration
runs created local files for all four anatomies and a noise-off UI export.

## What has NOT been established

- Training on licensed real experimental photoacoustic measurements.
- Empirical device noise estimation from a real receiver.
- Full IPASC conformance with PACFISH quality control.
- Experimental realism, clinical accuracy or anatomical fidelity.
- Verified numerical convergence against a trusted k-Wave implementation.
- Accurate multispectral hemoglobin parameterization or light transport.
- Improved downstream reconstruction/segmentation on independent patients.
- GPU, 3D, high-throughput performance, or data privacy audit.

These are **research release gates**. A passing unit test suite is not a
scientific validation of a generative biomedical data platform.
