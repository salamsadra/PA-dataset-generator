# PA-FORGE v0.2 validation report

Generated from executed source-code tests and `examples/research_benchmark/metrics.csv`.

## Local verification

- `pytest -q`: **39 passed** on the available local Python environment (3.13, NumPy 2.3.5, SciPy 1.17.0, PyTorch 2.10.0 CPU, Gradio 6.5.1). Actual test output recorded during development.
- Standalone `paforge demo`: vascular 96×96, 48 detectors, 420 time steps, `--no-filter`, iterative image reconstruction, *noise OFF* successfully wrote raw HDF5, anatomy classes, image HDF5 and preview.
- `generate_ui` directly generated ZIP output in both `ubp` and `iterative` configurations; GUI object instantiated successfully.
- `paforge benchmark`: 3 seeds × 2 noise conditions × 3 methods, **18 synthetic metrics rows**.
- Unfiltered FDTD forward and transpose tested numerically with homogeneous and heterogeneous sound speed; finite dot products agreed within specified tolerances.
- Config with every noise engine named but `enabled=false` produced bitwise identical clean/raw time series.
- Dataset import schema and group split functions exercised on controlled synthetic test files.

## Synthetic benchmark (grid 64, 24 detectors, 12 iterations, 3 seeds)

All quantities are **synthetic internal numerical checks only**, not real experiments.

| Noise case | Reconstruction | Mean Pearson r | Mean oracle-scale NRMSE |
|---|---|---:|---:|
| noise_off | das | -0.014 | 0.986 |
| noise_off | ubp | 0.400 | 0.810 |
| noise_off | iterative_matched_fdtd | 0.899 | 0.386 |
| gaussian_colored | das | -0.010 | 0.986 |
| gaussian_colored | ubp | 0.400 | 0.810 |
| gaussian_colored | iterative_matched_fdtd | 0.898 | 0.387 |

**Scientific interpretation:** Derivative-weighted backprojection improves over the naive DAS baseline in this setting. Iterative recovery reaches higher correlation partly because the synthetic data and inverse use the same FDTD operator, a deliberate inverse crime for numerical verification. The oracle NRMSE uses truth-derived scale, so it is not a deployable quantitative reconstruction metric. No real-world generalization performance can be inferred.

## Explicitly not validated

1. No experimental PA archive actually downloaded, parsed or harmonized.
2. No patient/phantom cross-device external validation, no published dataset test metrics.
3. No comparison to independently implemented k-Wave, no optical Monte Carlo.
4. No real tissue-calibrated wavelengths/Hb spectra, noise PSD or transducer response.
5. No IPASC/PACFISH conformance certification.
6. No real trained generative model. Demo multiclass CVAE training is procedural-only and may fail if undertrained.
7. Physically accurate 3D human networks, physiological artery/vein blood oxygenation and calibration are out of scope for this release.

## Reproduction

```bash
python -m pip install -e '.[dev,ui,train]'
python -m pytest -q
paforge benchmark --anatomy vascular --seeds 3 --iterations 12 --grid 64 --transducers 24 --output replicated_benchmark
paforge demo --anatomy vascular --reconstruction-method iterative --no-filter --no-noise --grid-size 96 --time-steps 420 --transducers 48 --output replicated_vascular
```

See `RESEARCH_PROTOCOL.md` and `DATASET_PLAN.md` for future real-data publication gates.
