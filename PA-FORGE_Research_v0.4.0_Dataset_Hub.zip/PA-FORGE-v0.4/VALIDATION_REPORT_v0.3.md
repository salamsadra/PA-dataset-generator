# PA-FORGE v0.3 — Verification Report (2026-10-28)

## Implemented

- Runs the v0.2 acoustic/optical and anatomy generators, five independent noise engines (noise OFF by default), raw-signal generation and qualitative/iterative reconstruction.
- Adds `download-openqpai` (opt-in, checksum-verified acquisition of InVision/TROPUS and DIS archives from the upstream Zenodo page for users with network access).
- Adds `extract-acquisition` (high-dimensional HDF5 with explicit axes/frame/metadata; no silent wavelength or coordinate inference).
- Adds `validate-domains` (group-disjoint train/test and matched acquisition shape/rate requirements; spectral-domain statistical filter trained on train only; held-out distribution metrics; file-hash provenance).
- Adds optional measured quiet-window extraction to a noise-library file compatible with the existing empirical noise engine.
- Adds `apply-domain-profile` (frozen deterministic synthetic-domain adaptation, not physically measured device response).
- Adds `reconstruct-acquisition` (qualitative DAS/derivative backprojection on genuine imported raw traces, measured sensor coordinates mandatory).

## Verification performed in this runtime

- 46 automated tests passed, including prior physics/noise/vascular numerical tests and the new experimental-pipeline tests.
- The real-acquisition reconstruction command was independently smoke-tested on an **existing PA-FORGE synthetic HDF5** with detector coordinates; an output image was produced and its manifest explicitly states synthetic origin.
- New experimental-pipeline unit tests explicitly generate **MOCK waveforms**, not actual measurements. Their pass status verifies software functionality only. They must not be cited as evidence of simulation-to-real success.
- No independent real photoacoustic HDF5 files were accessible locally. The environment could not access external archive download hosts; an attempted Zenodo download failed.
- No calibrated forward solver comparison against measured optical/acoustic parameters was executed.
- No held-out experimental reconstruction result, reference comparison, or instrument-level validation was obtained. No experimental improvement figure is reported.

## Scientific status (read before citing)

| Milestone | Status |
|---|---|
| Code for high-dimensional experimental HDF5 ingestion | Implemented, smoke tested |
| Provenance checks and group-disjoint test protection | Implemented, unit tested |
| Train-only statistical waveform calibration | Implemented, unit tested with artificial waveforms |
| Domain-shift comparison on genuine held-out experiments | **PENDING original real files** |
| Reconstructed qualitative image from genuine acquisition | **PENDING original real signals and coordinates** |
| Physics-based quantitative detector calibration | **NOT DONE** |
| k-Wave/Monte-Carlo cross-validation | **NOT DONE** |
| Human simulation-to-real reconstruction improvement | **NOT DONE** |

This is an executable *experimental research workflow*, not a scientifically established experimental result.
