"""Command line entry points."""
from pathlib import Path
import json
import typer
import yaml
from .config import SimConfig,NoiseConfig,preset
from .pipeline import run_batch
from .datasets import inspect_file,import_measurement
from .io import plot_preview
app=typer.Typer(help="PA-FORGE physics-grounded photoacoustic research prototype")

# Dataset acquisition is opt-in: never download huge third-party archives during install.
datasets_app=typer.Typer(help="Discover and download external photoacoustic research datasets")
app.add_typer(datasets_app,name="datasets")


@datasets_app.command("list")
def datasets_list():
    """List every supported publisher, role, and access mode (offline)."""
    from .dataset_hub import SOURCES
    typer.echo(json.dumps([{'id':s.id,'title':s.title,'provider':s.provider,
                            'role':s.role,'license':s.license_note,'url':s.record,
                            'anatomy':s.anatomy} for s in SOURCES],indent=2))


@datasets_app.command("inspect")
def datasets_inspect(dataset:str):
    """Query upstream metadata; show real filenames, sizes and publisher digests."""
    from .dataset_hub import discover
    try:
        typer.echo(json.dumps(discover(dataset),indent=2))
    except Exception as e:
        typer.echo(f"Publisher discovery failed: {e}",err=True)
        raise typer.Exit(code=1)


@datasets_app.command("download")
def datasets_download(dataset:list[str]=typer.Option([],"--dataset","-d",help="Repeatable source ID"),
                     all_sources:bool=typer.Option(False,"--all",help="Include every catalog source"),
                     output:Path=typer.Option(Path('data/external'),"--output","-o"),
                     profile:str=typer.Option('starter',"--profile",help="starter or full"),
                     accept_licenses:bool=typer.Option(False,"--accept-licenses",help="Acknowledge upstream license review"),
                     max_file_gb:float=typer.Option(2.,"--max-file-gb"),
                     max_total_gb:float=typer.Option(5.,"--max-total-gb"),
                     unpack:bool=typer.Option(False,"--unpack",help="Optional safe archive unpacking"),
                     dry_run:bool=typer.Option(False,"--dry-run",help="Discover and budget, no downloads")):
    """Download from publisher APIs with resume, checksums and truthful per-source status."""
    from .dataset_hub import run_download
    if not all_sources and not dataset:
        typer.echo("Pass --all or one or more --dataset IDs (see 'paforge datasets list')",err=True)
        raise typer.Exit(code=2)
    try:
        report=run_download(None if all_sources else dataset,output,profile=profile,
                            accept_licenses=accept_licenses,max_file_gb=max_file_gb,
                            max_total_gb=max_total_gb,unpack=unpack,dry_run=dry_run)
    except Exception as e:
        typer.echo(str(e),err=True)
        raise typer.Exit(code=2)
    typer.echo(json.dumps({'status':{k:v['status'] for k,v in report['sources'].items()},
                           'scheduled_gb':round(report['scheduled_bytes']/1e9,3),
                           'report':report.get('report_path'),
                           'details':report['sources']},indent=2))
    if any(x['status'] in ('discovery_error','no_files_downloaded','error') for x in report['sources'].values()):
        raise typer.Exit(code=1)



@app.command()
def demo(output:Path=typer.Option(Path("outputs"),"--output","-o"),
         anatomy:str=typer.Option("forearm","--anatomy"),
         samples:int=typer.Option(1,"--samples"),
         noise:bool=typer.Option(False,"--noise/--no-noise"),
         engine:list[str]=typer.Option(None,"--engine"),
         seed:int=typer.Option(42,"--seed"),
         reconstruction_method:str=typer.Option("das","--reconstruction-method"),
         grid_size:int=typer.Option(96,"--grid-size"),
         time_steps:int=typer.Option(380,"--time-steps"),
         transducers:int=typer.Option(64,"--transducers"),
         detector_filter:bool=typer.Option(True,"--filter/--no-filter"),
         vascular_pattern:str=typer.Option("branching","--vascular-pattern")) :
    """Run a complete reproducible forward simulation, reconstruction and export."""
    base=preset(anatomy)
    engines=engine if engine else ["gaussian"]
    cfg=SimConfig.model_validate({**base.model_dump(),"samples":samples,"seed":seed,
        "reconstruction_method":reconstruction_method,"grid_size":grid_size,
        "time_steps":time_steps,"transducers":transducers,
        "detector_filter":detector_filter,"vascular_pattern":vascular_pattern,
        "noise":{"enabled":noise,"engines":engines}})
    paths=run_batch(cfg,output)
    if cfg.export_truth and cfg.export_images and cfg.reconstruct:
        plot_preview(paths[0])
    typer.echo(json.dumps({"samples":len(paths),"first_sample":str(paths[0]),"noise_enabled":noise},indent=2))


@app.command()
def generate(config:Path, output:Path=typer.Option(Path("outputs"),"--output","-o")):
    """Generate from a YAML config; see examples/config.yaml."""
    cfg=SimConfig.model_validate(yaml.safe_load(config.read_text()))
    paths=run_batch(cfg,output)
    if cfg.export_truth and cfg.export_images and cfg.reconstruct:plot_preview(paths[0])
    typer.echo(f"Completed {len(paths)} samples under {output}")


@app.command("inspect-data")
def inspect_data(path:Path):
    """Inspect uploaded experimental HDF5/MAT/NPZ without assuming array axes."""
    typer.echo(json.dumps(inspect_file(path),indent=2))


@app.command("import-data")
def import_data(path:Path, key:str=typer.Option(...,"--key"),
                output:Path=typer.Option(...,"--output"),
                detector_axis:int=typer.Option(...,"--detector-axis"),
                sampling_rate:float=typer.Option(...,"--sampling-rate-hz"),
                wavelength:float=typer.Option(...,"--wavelength-nm"),
                positions:Path=None):
    """Explicit experimental raw-array import; provenance, axes, units required."""
    dest=import_measurement(path,key,output,detector_axis,sampling_rate,wavelength,positions)
    typer.echo(str(dest))


@app.command("train-demo")
def train_demo(output:Path=typer.Option(Path("examples/demo_cvae.pt"),"--output"),
               epochs:int=typer.Option(1,"--epochs",min=1),
               n:int=typer.Option(32,"--samples",min=8)):
    """Train cVAE on procedural vessels ONLY (not experimental!)."""
    from .learned import create_procedural_training_set,train_cvae
    path=output.with_suffix(".npz")
    create_procedural_training_set(path,n)
    typer.echo(f"Procedural-only vessel masks saved: {path}")
    losses=train_cvae(path,output,epochs=epochs)
    typer.echo(f"Saved {output}. Loss history: {losses}")


@app.command("train-cvae")
def train_real(dataset:Path, weights:Path,epochs:int=10,batch_size:int=16):
    """Train on curated, segmented masks, not on unlabeled raw signals."""
    from .learned import train_cvae
    typer.echo(str(train_cvae(dataset,weights,epochs,batch_size)))



@app.command("benchmark")
def benchmark(output:Path=typer.Option(Path("research_results"),"--output","-o"),
              anatomy:str=typer.Option("vascular","--anatomy"),
              seeds:int=typer.Option(2,"--seeds",min=1,max=50),
              iterations:int=typer.Option(10,"--iterations",min=1,max=100),
              grid:int=typer.Option(64,"--grid",min=48,max=256),
              transducers:int=typer.Option(24,"--transducers",min=8,max=512)):
    """Paired noisy/noiseless synthetic reconstruction baselines. NOT real-data validation."""
    from .research import run_benchmark
    path,summary=run_benchmark(output,anatomy=anatomy,seeds=tuple(7+6*i for i in range(seeds)),
            grid=grid,transducers=transducers,iterations=iterations)
    typer.echo(f"Synthetic-only benchmark: {path}; {len(summary['results'])} measurements")



@app.command("train-vascular-demo")
def train_vascular_demo(weights:Path=typer.Option(Path("models/vascular_synthetic_demo.pt"),"--weights"),
                        samples:int=typer.Option(60,"--samples",min=8),
                        epochs:int=typer.Option(4,"--epochs",min=1)):
    """Train vessel-class CVAE on synthetic masks ONLY (demonstration)."""
    from .vascular_cvae import create_demo_masks,train
    data=weights.with_suffix('.npz')
    create_demo_masks(data,samples)
    history=train(data,weights,epochs=epochs)
    typer.echo(json.dumps({'weights':str(weights),'source':'procedural synthetic only',
        'loss_history':history},indent=2))

@app.command("train-vascular")
def train_vascular(dataset:Path,weights:Path,epochs:int=10,batch_size:int=12):
    """Train four-class vascular CVAE on curated segmentation maps [N,64,64]."""
    from .vascular_cvae import train
    history=train(dataset,weights,epochs=epochs,batch_size=batch_size)
    typer.echo(json.dumps({'weights':str(weights),'loss_history':history},indent=2))



@app.command("make-splits")
def make_splits(metadata_csv:Path,output:Path=typer.Option(Path('splits'),'--output'),
                group_column:str=typer.Option('subject_id','--group-column'),
                seed:int=typer.Option(42,'--seed')):
    """Generate group-disjoint train/validation/test splits from metadata CSV."""
    from .splits import group_split
    manifest=group_split(metadata_csv,output,group_column=group_column,seed=seed)
    typer.echo(json.dumps({'splits':str(output),'groups':manifest['num_independent_groups']},indent=2))



@app.command("extract-acquisition")
def extract_acquisition(path:Path,key:str=typer.Option(...,"--key"),output:Path=typer.Option(...,"--output"),
             detector_axis:int=typer.Option(...,"--detector-axis"),time_axis:int=typer.Option(...,"--time-axis"),
             fixed_axis:list[str]=typer.Option([],"--fixed-axis",help="axis=index, repeat for all other axes"),
             sampling_rate_hz:float=typer.Option(...,"--sampling-rate-hz"),
             wavelength_nm:float=typer.Option(...,"--wavelength-nm"),
             source_id:str=typer.Option(...,"--source-id"),
             group_id:str=typer.Option(...,"--group-id"),
             experimental_attestation:bool=typer.Option(False,"--attest-experimental"),
             positions:Path=None):
    """Extract exactly one genuine raw acquisition from an HDF5 array."""
    from .experimental_import import extract_hdf5_acquisition
    fixed={}
    for item in fixed_axis:
        if '=' not in item:raise typer.BadParameter("--fixed-axis must be axis=index")
        a,i=item.split('=',1);fixed[int(a)]=int(i)
    path=extract_hdf5_acquisition(path,key,output,detector_axis,time_axis,fixed,sampling_rate_hz,
           wavelength_nm,source_id,group_id,experimental_attestation,positions)
    typer.echo(f"Exported original experimental acquisition to {path}")


@app.command("validate-domains")
def validate_domains(manifest:Path=typer.Argument(...,help="CSV manifest of independent real/synthetic acquisitions"),
                     output:Path=typer.Option(Path("experimental_results"),"--output"),
                     extract_quiet_noise:bool=typer.Option(False,"--extract-quiet-noise")):
    """Fit a TRAIN-only spectral match and evaluate a frozen held-out signal distribution."""
    from .experimental import run_experiment
    res=run_experiment(manifest,output,quiet_mode='extract' if extract_quiet_noise else 'none')
    typer.echo(json.dumps({'status':res['status'],'metrics':res['heldout_metrics'],
      'output':str(output)},indent=2))


@app.command("reconstruct-acquisition")
def reconstruct_acquisition(path:Path,output:Path=typer.Option(Path('real_reconstruction'),'--output'),
            method:str=typer.Option('ubp','--method'),fov_m:float=typer.Option(0.04,'--fov-m'),
            grid_size:int=typer.Option(128,'--grid-size'),sound_speed_m_s:float=typer.Option(1500.,'--sound-speed-m-s'),
            positions:Path=None):
    """Qualitative reconstruction from REAL measured signals using real coordinates."""
    from .experimental_reconstruction import reconstruct_experimental
    rec=reconstruct_experimental(path,output,method,fov_m,grid_size,sound_speed_m_s,positions)
    typer.echo(json.dumps({'output':str(output),'image_shape':rec.shape,'quantitative':False}))


@app.command("apply-domain-profile")
def apply_domain_profile(synthetic_h5:Path,profile_json:Path,output:Path=typer.Option(...,'--output')):
    """Apply frozen train-only statistical spectral adaptation to synthetic signals."""
    from .domain_adapter import adapt_synthetic
    dest=adapt_synthetic(synthetic_h5,profile_json,output)
    typer.echo(f"Domain-adapted synthetic signals written: {dest} (NOT physical device calibration)")


@app.command("download-openqpai")
def download_openqpai(output:Path=typer.Option(Path('data/openqpai'),'--output'),
                      archive:str=typer.Option('invision','--archive',help='invision/tropus/dis'),
                      unpack:bool=typer.Option(False,'--unpack')):
    """Fetch published experimental archives with original MD5 verification."""
    from .download_data import fetch_openqpai
    typer.echo(json.dumps(fetch_openqpai(output,archive,unpack),indent=2))

@app.command("ui")
def ui(port:int=7860):
    from .ui import build_ui
    build_ui().launch(server_name="127.0.0.1",server_port=port)

if __name__=="__main__":app()
