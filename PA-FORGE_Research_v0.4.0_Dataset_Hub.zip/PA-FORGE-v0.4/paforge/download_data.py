"""Explicit, checksum-verified public experimental archive download helpers.

Never auto-download data at import or install time. OpenQPAIData source data are
licensed by upstream authors; preserve the upstream README and credit them.
"""
import hashlib
import shutil
import urllib.request
import zipfile
from pathlib import Path

OPENQPAI = {
    'invision':('invision.zip','a3ab81d0256feb2ffa8412b3ed40efa6'),
    'tropus':('tropus.zip','e826db69f96eeeadb7e18a459114b9e9'),
    'dis':('DIS.zip','3ad5e85f91aed6fbaad978d8a8d94515'),
}
BASE='https://zenodo.org/records/14044853/files/'


def fetch_openqpai(target, kind='invision', unpack=False):
    if kind not in OPENQPAI:raise ValueError(f"Choose one of {sorted(OPENQPAI)}")
    filename,md5=OPENQPAI[kind]
    target=Path(target);target.mkdir(parents=True,exist_ok=True)
    dest=target/filename
    temp=target/(filename+'.partial')
    if not dest.exists():
        req=urllib.request.Request(BASE+filename+'?download=1',headers={'User-Agent':'PA-FORGE-research/0.3'})
        try:
            with urllib.request.urlopen(req,timeout=40) as response,open(temp,'wb') as out:
                shutil.copyfileobj(response,out,1024*1024)
        except Exception:
            temp.unlink(missing_ok=True)
            raise
        temp.replace(dest)
    hasher=hashlib.md5()
    with dest.open('rb') as f:
        for chunk in iter(lambda:f.read(4*1024*1024),b''):hasher.update(chunk)
    if hasher.hexdigest()!=md5:
        raise ValueError(f'Checksum mismatch for {dest}: expected {md5}, found {hasher.hexdigest()}. Remove corrupt file and retry.')
    unpack_dir=None
    if unpack:
        unpack_dir=target/kind
        unpack_dir.mkdir(exist_ok=True)
        with zipfile.ZipFile(dest) as z:
            for member in z.infolist():
                path=(unpack_dir/member.filename).resolve()
                if not path.is_relative_to(unpack_dir.resolve()):
                    raise ValueError('Unsafe archive path detected')
                # Reject Unix symbolic links in zip archives
                if (member.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('Symlink in zip not permitted')
            z.extractall(unpack_dir)
    return {'archive':str(dest),'upstream_md5_verified':True,'unpacked_to':str(unpack_dir) if unpack else None,
            'source':'https://zenodo.org/records/14044853','license':'CC-BY-4.0 (upstream)' }
