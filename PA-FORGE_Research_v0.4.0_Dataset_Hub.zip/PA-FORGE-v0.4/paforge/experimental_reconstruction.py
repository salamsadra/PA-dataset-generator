"""Qualitative experimental image reconstruction (not a clinical/reference standard).

Requires measured detector coordinates. No fabricated ring/arc device geometry;
for 3D sensors the chosen 2D projection must be documented and justified.
"""
from pathlib import Path
import json
import h5py
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .config import SimConfig
from .acoustic import reconstruct_ubp, reconstruct_das


def reconstruct_experimental(input_h5,output,method='ubp',fov_m=0.04,grid_size=128,
                             sound_speed_m_s=1500.0,positions_file=None):
    if method not in ('ubp','das'):raise ValueError('Supported qualitative methods: ubp, das')
    if not(0.005<=fov_m<=0.3):raise ValueError('FOV must be 5–300 mm')
    if not(1000<=sound_speed_m_s<=2200):raise ValueError('Check sound speed, expected 1000–2200 m/s')
    p=Path(input_h5)
    with h5py.File(p,'r') as f:
        if 'raw_data' not in f:raise ValueError('No /raw_data in source file')
        traces=f['raw_data'][:]
        fs=float(f.attrs.get('sampling_rate_hz',0))
        if fs<=0:raise ValueError('Missing verified sampling rate')
        if positions_file is None:
            if 'detector_positions_m' not in f:raise ValueError('Missing detector geometry. Use --positions with measured coordinates; do not invent a circle.')
            pos=f['detector_positions_m'][:]
        else:pos=np.load(positions_file,allow_pickle=False)
        provenance=str(f.attrs.get('source_id','unspecified'))
        is_synthetic=bool(f.attrs.get('synthetic',False))
    if traces.ndim!=2:raise ValueError('Expected [detectors,time]')
    if pos.shape!=(traces.shape[0],3) or not np.isfinite(pos).all():raise ValueError('Positions must be finite [detectors,3] in metres')
    if np.ptp(pos[:,2])>0.002:
        raise ValueError('Significant 3D sensor spread: 2D projection is not geometrically valid. Need a 3D reconstruction method.')
    config=SimConfig(grid_size=grid_size,transducers=traces.shape[0],fov_m=fov_m,
        sound_speed_offset_m_s=sound_speed_m_s-1480.,detector_filter=False)
    fn=reconstruct_ubp if method=='ubp' else reconstruct_das
    rec=fn(traces,1/fs,pos,config)
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    with h5py.File(output/'experimental_reconstruction.h5','w') as f:
        f.attrs['method']=method
        f.attrs['quantitative']=False
        f.attrs['source_id']=provenance
        f.attrs['source_synthetic']=is_synthetic
        f.attrs['warnings']='Qualitative 2D homogeneous-speed backprojection. Unverified detector response, alignment and illumination.'
        f.create_dataset('image',data=rec,compression='gzip')
    plt.imsave(output/'experimental_reconstruction.png',rec,cmap='magma')
    (output/'reconstruction_manifest.json').write_text(json.dumps({
        'source':str(p),'source_id':provenance,'source_synthetic':is_synthetic,
        'method':method,'fov_m':fov_m,'grid_size':grid_size,
        'sound_speed_m_s':sound_speed_m_s,'signal_sampling_hz':fs,
        'status':'qualitative experimental reconstruction ONLY' if not is_synthetic else 'synthetic reconstruction smoke test',
        'limitations':['No device point spread function calibration','2D homogeneous wave assumption',
                       'Orientation and registration against reference image not established']},indent=2))
    return rec
