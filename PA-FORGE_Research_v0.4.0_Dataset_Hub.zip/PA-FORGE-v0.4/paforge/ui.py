"""Interactive Gradio control panel. Runs locally, no cloud data transfer."""
import tempfile
import zipfile
from pathlib import Path
from .config import preset,SimConfig
from .pipeline import run_batch
from .io import plot_preview


def _bundle(folder):
    archive=folder/"pa_forge_outputs.zip"
    with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for f in folder.rglob("*"):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(folder))
    return str(archive)


def generate_ui(anatomy,samples,seed,noise_enabled,noise_engines,noise_std,empirical_path,
                wavelength,transducers,geometry,center_mhz,bandwidth_mhz,
                sound_var,scattering,laser_jitter,dropout,grid,time_steps,
                vascular_pattern,vascular_branches,vascular_density,
                recon_method,recon_iterations,filter_enabled,
                illumination,anatomy_engine,generator_weights):
    base=preset(anatomy)
    config={**base.model_dump(),"samples":int(samples),"seed":int(seed),
            "grid_size":int(grid),"time_steps":int(time_steps),
            "vascular_pattern":vascular_pattern,"vascular_branch_levels":int(vascular_branches),
            "vascular_density":vascular_density,"reconstruction_method":recon_method,
            "illumination_model":illumination,"anatomy_engine":anatomy_engine,
            "generator_weights":generator_weights.strip() or None,
            "reconstruction_iterations":int(recon_iterations),"detector_filter":bool(filter_enabled),
            "wavelength_nm":int(wavelength),"transducers":int(transducers),
            "geometry":geometry,"center_frequency_hz":center_mhz*1e6,
            "bandwidth_hz":bandwidth_mhz*1e6,
            "sound_speed_variation_fraction":sound_var,"scattering_scale":scattering,
            "pulse_energy_jitter_fraction":laser_jitter,
            "channel_dropout_probability":dropout,
            "noise":{"enabled":bool(noise_enabled),"engines":noise_engines,
                     "relative_std":noise_std,"empirical_path":empirical_path.strip() or None}}
    cfg=SimConfig.model_validate(config)
    output=Path(tempfile.mkdtemp(prefix="paforge_"))
    results=run_batch(cfg,output)
    overview=plot_preview(results[0])
    archive=_bundle(output)
    import json
    return str(overview),archive,json.dumps({"config":cfg.model_dump(mode="json"),"output_dir":str(output)},indent=2)


def build_ui():
    import gradio as gr
    with gr.Blocks(title="PA-FORGE | Synthetic Photoacoustic Data") as demo:
        gr.Markdown("# PA-FORGE · Photoacoustic Data Generator\n**Local research prototype.** 2D approximate physics; no experimental realism certification.")
        with gr.Row():
            with gr.Column(scale=2):
                anatomy=gr.Dropdown(["forearm","skin","breast","carotid","vascular"],value="vascular",label="Anatomical region")
                samples=gr.Slider(1,25,value=1,step=1,label="Samples in this interactive run")
                seed=gr.Number(value=42,precision=0,label="Reproducibility seed")
                with gr.Accordion("Vascular network (arteries, veins, capillaries)",open=True):
                    vascular_pattern=gr.Dropdown(["branching","paired","plexus"],value="branching",label="Network pattern (vascular mode)")
                    vascular_branches=gr.Slider(1,5,value=3,step=1,label="Branch levels")
                    vascular_density=gr.Slider(.2,3,value=1,step=.1,label="Capillary density multiplier")
                with gr.Accordion("Reconstruction",open=True):
                    recon_method=gr.Dropdown(["ubp","das","adjoint","iterative"],value="ubp",label="Reconstruction method")
                    recon_iterations=gr.Slider(1,50,value=8,step=1,label="Iterative solver steps")
                    filter_enabled=gr.Checkbox(value=True,label="Apply detector bandpass (turn OFF for matched iterative inversion)")
                with gr.Accordion("Learned vs procedural anatomy",open=False):
                    anatomy_engine=gr.Dropdown(["procedural","cvae","vascular_cvae"],value="procedural",label="Anatomy generator")
                    generator_weights=gr.Textbox(value="",label="Trusted local model weights path (required for cVAE)")
                with gr.Accordion("Noise engines · completely optional",open=True):
                    noise=gr.Checkbox(value=False,label="Enable added noise (OFF by default)")
                    engines=gr.CheckboxGroup(["gaussian","colored","impulsive","drift","empirical"],value=["gaussian"],label="Active engines (only run when enabled)")
                    strength=gr.Slider(0,0.3,value=.025,step=.005,label="Noise SD relative to clean waveform RMS")
                    empirical=gr.Textbox(label="Trusted local empirical noise path (required when engine selected)",value="")
                with gr.Accordion("Acquisition and device settings",open=False):
                    illumination=gr.Dropdown(["attenuation_proxy","uniform_idealized"],value="uniform_idealized",label="Optical fluence model (uniform is idealized; scattering ignored)")
                    wavelength=gr.Slider(660,1300,value=800,step=10,label="Laser wavelength (nm)")
                    transducers=gr.Slider(8,128,value=64,step=8,label="Transducer count")
                    geometry=gr.Dropdown(["circle","arc","linear"],value="circle",label="Acquisition geometry")
                    center=gr.Slider(.4,3,value=1.8,step=.1,label="Detector center frequency (MHz)")
                    bandwidth=gr.Slider(.3,3,value=1.8,step=.1,label="Detector bandwidth (MHz)")
                    sound=gr.Slider(0,2,value=1,step=.1,label="Sound speed anatomical variation multiplier")
                    scattering=gr.Slider(.1,3,value=1,step=.1,label="Optical reduced scattering multiplier")
                    laser=gr.Slider(0,.2,value=0,step=.005,label="Pulse energy jitter fraction")
                    drop=gr.Slider(0,.5,value=0,step=.01,label="Channel dropout probability")
                    grid=gr.Dropdown([64,96,128],value=96,label="Spatial grid points per dimension")
                    steps=gr.Slider(200,800,value=380,step=20,label="Time steps")
                # Keep anatomy-specific geometry defaults when switching regions.
                anatomy.change(fn=lambda a: gr.update(value=preset(a).geometry),inputs=anatomy,outputs=geometry)
                anatomy.change(fn=lambda a: gr.update(value=preset(a).illumination_model),inputs=anatomy,outputs=illumination)
                recon_method.change(fn=lambda m: gr.update(value=False) if m=="iterative" else gr.update(),
                                    inputs=recon_method,outputs=filter_enabled)
                # Only a well-documented default geometry should change with anatomy.
                button=gr.Button("Generate simulated signals and images",variant="primary")
            with gr.Column(scale=3):
                gr.Markdown("### Outputs · raw signals and images stored separately")
                preview=gr.Image(type="filepath",label="Initial pressure · measured traces · image reconstruction")
                archive=gr.File(label="ZIP containing HDF5 raw signals, reconstructed image, and truth")
                metadata=gr.Code(label="Reproducible configuration",language="json")
        button.click(fn=generate_ui,inputs=[anatomy,samples,seed,noise,engines,strength,empirical,
                       wavelength,transducers,geometry,center,bandwidth,sound,scattering,laser,drop,grid,steps,
                       vascular_pattern,vascular_branches,vascular_density,recon_method,recon_iterations,filter_enabled,
                       illumination,anatomy_engine,generator_weights],
                     outputs=[preview,archive,metadata])
        gr.Markdown("**Important:** No added noise ≠ noiseless real hardware. IPASC conformance and patient-data realism remain unvalidated.")
    return demo
